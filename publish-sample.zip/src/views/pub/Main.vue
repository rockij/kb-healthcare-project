<template>
  <div class="contents">main</div>
</template>

<script>
  export default {
    setup() {
      return {}
    }
  }
</script>
