<template>
  <div class="contents">
    <div class="title-area">
      <p class="subTit-01">회원님의 오케어 탈퇴가 <br />완료되었습니다</p>
      <p class="desc pt-4 desc-done">
        그동안 오케어를 이용해 주셔서 감사합니다<br />
        더욱 노력하는 오케어가 되겠습니다 <br />감사합니다
      </p>
    </div>
    <div class="btn-bottom">
      <div class="btn-area d-flex">
        <v-btn variant="text" height="56px" class="btn-summit">확인</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    setup() {
      return {}
    }
  }
</script>

<style lang="scss" scoped></style>
