<template>
  <div class="contents">
    <HospitalCard
      v-for="item in hospitalList"
      :key="item.id"
      :articleClass="item.articleClass"
      :titleBisde="item.titleBisde"
      :title="item.title"
      :titleClass="item.titleClass"
      :datalstClass="item.datalstClass"
      :road="item.road"
      :subject="item.subject"
      :divider="false"
      :tags="item.tags"
      :state="item.state"
      :stateClass="item.stateClass"
    />
    <buttonSns :snsBtns="snsBtns" class="mt-4" />
    <div class="section-page mt-8">
      <h3 class="tit-02">진료시간</h3>
      <div class="list-bside mt-3">
        <ul class="list">
          <li v-for="item in timeTable" :key="item.id">
            <span class="title ws-95">{{ item.title }}</span>
            <span class="text">{{ item.text }}</span>
          </li>
        </ul>
        <p class="caution mt-2">접수마감은 진료시간 60분전입니다</p>
      </div>
      <div class="list-schedule mt-6">
        <ul class="list">
          <li v-for="item in scheduleTable" :key="item.id">
            <strong class="title">{{ item.title }}</strong>
            {{ item.text }}
          </li>
        </ul>
      </div>
    </div>
    <div class="section-page">
      <h3 class="tit-02">진료과목</h3>
      <p class="mt-3">정형외과, 재활의학과 ,성형외과,마취통증의학과</p>
    </div>
    <div class="section-page">
      <h2 class="tit-02">전문의</h2>
      <p class="mt-3">이비인후과 전문의 2명, 내과 전문의 2명</p>
    </div>
    <div class="section-page">
      <h3 class="tit-02">위치</h3>
      <div class="list-iconlst mt-2">
        <ul class="list">
          <li data-icon="map">
            서울시 강남구 대치동 669-13
            <v-btn variant="text" class="btn-grayline">주소복사</v-btn>
          </li>
          <li data-icon="call">
            <a href="tel:02-554-5547">02-554-5547</a>
          </li>
        </ul>
        <div class="mapview">
          <!-- 지도영역 -->
          <img src="@/assets/images/dummy-map2.png" class="img" alt="" />
          <!-- //지도영역 -->
        </div>
      </div>
      <div class="caution-box mt-8">
        <h4 class="title">알려드립니다</h4>
        병원정보는 건강보험심사평가원의 의료 빅데이터를 활용하여 제공합니다
      </div>
    </div>
  </div>
</template>
<script>
  import buttonSns from '@/components/ButtonSns.vue'
  import HospitalCard from '@/components/CardHospital.vue'
  import { reactive } from 'vue'
  export default {
    components: {
      HospitalCard,
      buttonSns
    },
    data() {
      return {
        timeTable: [
          {
            id: 1,
            title: '수요일 진료',
            text: '09:00 ~ 18:00'
          },
          {
            id: 2,
            title: '점심시간',
            text: '13:00 ~ 14:00'
          }
        ],
        scheduleTable: [
          {
            id: 1,
            title: '월요일',
            text: '09:00 ~ 18:00'
          },
          {
            id: 2,
            title: '화요일',
            text: '09:00 ~ 18:00'
          },
          {
            id: 3,
            title: '수요일',
            text: '09:00 ~ 18:00'
          },
          {
            id: 4,
            title: '목요일',
            text: '09:00 ~ 18:00'
          },
          {
            id: 5,
            title: '금요일',
            text: '09:00 ~ 18:00'
          },
          {
            id: 6,
            title: '토요일',
            text: '09:00 ~ 18:00'
          },
          {
            id: 7,
            title: '일요일',
            text: '09:00 ~ 18:00'
          },
          {
            id: 8,
            title: '공휴일',
            text: '09:00 ~ 18:00'
          }
        ]
      }
    },
    setup() {
      const hospitalList = reactive([
        {
          id: 1,
          articleClass: 'type',
          titleBisde: true,
          title: '강남초이스영상의학과의원',
          titleClass: 'fs-26 font-weight-bold me-auto',
          title2: '서울특별시 강남구 테헤란로 401 0층 0호',
          title2Class: 'mt-5',
          datalstClass: 'mt-4',
          road: '5m',
          subject: '이비인후과 전문의 1명, 내과전문의 1명',
          tags: '#여의사 #야간진료 #주말진료',
          state: '진료종료',
          stateClass: 'waiting',
          path: '/MAJ0305740'
        }
      ])
      const snsBtns = reactive([
        {
          id: 1,
          title: '전화연결',
          class: 'call',
          tel: '02-554-5547'
        },
        {
          id: 2,
          title: '공유하기',
          class: 'share',
          func: funcSns
        },
        {
          id: 3,
          title: '즐겨찾기',
          class: 'mark',
          func: funcFavorit
        },
        {
          id: 4,
          title: '길찾기',
          class: 'map',
          func: funcMap
        }
      ])
      function funcSns() {
        alert('공유하기')
      }
      function funcFavorit() {
        alert('즐겨찾기')
      }
      function funcMap() {
        alert('길찾기')
      }
      return { hospitalList, snsBtns, funcSns, funcFavorit, funcMap }
    }
  }
</script>
