import axios from 'axios';
/**
 * 리스트 조회 ( category )
 * 
 */
export const _getCategoryList = async (params) => {
    return await 'test !!!';
    // return await $api.post('', params);
};